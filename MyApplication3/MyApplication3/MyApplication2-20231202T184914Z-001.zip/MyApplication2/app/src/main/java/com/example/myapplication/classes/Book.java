package com.example.myapplication.classes;

public class Book {

    private String title;
    private String author;
    private int coverResource;
    private String description;
    private String category;
    private String[] chapters;

    public Book(String title, String author, int coverResource, String category){
        this.title = title;
        this.author = author;
        this.coverResource = coverResource;
        this.category = category;
    }

    public String getTitle(){
        return this.title;
    }
    public String getAuthor(){
        return this.author;
    }
    public int getCoverResource(){
        return this.coverResource;
    }
    public String getCategory(){
        return this.category;
    }

    public String getDescription(){
        return this.description;
    }

    public String[] getChapters(){
        return this.chapters;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setCoverResource(int coverResource) {
        this.coverResource = coverResource;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setChapters(String[] chapters) {
        this.chapters = chapters;
    }



}
