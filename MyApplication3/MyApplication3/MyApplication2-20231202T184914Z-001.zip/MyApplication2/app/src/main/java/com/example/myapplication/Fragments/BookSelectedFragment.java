package com.example.myapplication.Fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ViewFlipper;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.myapplication.AppDatabase;
import com.example.myapplication.R;
import com.example.myapplication.classes.Book;
import com.example.myapplication.dao.PersonalBookDao;
import com.example.myapplication.entitys.PersonalBookEntity;

public class BookSelectedFragment extends Fragment {

    private PersonalBookEntity selectedBook;

    public BookSelectedFragment(PersonalBookEntity book) {
        this.selectedBook = book;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_selectedbook, container, false);

        ViewFlipper viewFlipper = view.findViewById(R.id.viewFlipper);

        String title = selectedBook.getTitle();
        String author = selectedBook.getAuthor();
        int coverResource = selectedBook.getCoverResource();

        ImageView imageView = view.findViewById(R.id.BookImage);
        imageView.setImageResource(coverResource);

        TextView textViewTitle = view.findViewById(R.id.TitleTextView);
        textViewTitle.setText(title);

        TextView textViewAuthor = view.findViewById(R.id.AuthorTextView);
        textViewAuthor.setText(author);

        Button buttonStats = view.findViewById(R.id.buttonStats);
        Button buttonComments = view.findViewById(R.id.buttonComments);
        Button buttonMoments = view.findViewById(R.id.buttonMoments);
        Button buttonAddComment = view.findViewById(R.id.newCommentButton);
        Button buttonAddMoment = view.findViewById(R.id.newMomentButton);
        Button buttonDelete = view.findViewById(R.id.buttonDelete);

        buttonStats.setSelected(true);

        buttonStats.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonStats.setSelected(true);
                buttonComments.setSelected(false);
                buttonMoments.setSelected(false);
                viewFlipper.setDisplayedChild(0);
            }
        });

        buttonComments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonStats.setSelected(false);
                buttonComments.setSelected(true);
                buttonMoments.setSelected(false);
                viewFlipper.setDisplayedChild(1);
            }
        });

        buttonMoments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonStats.setSelected(false);
                buttonComments.setSelected(false);
                buttonMoments.setSelected(true);
                viewFlipper.setDisplayedChild(2);
            }
        });

        buttonAddComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
                FragmentTransaction transaction = fragmentManager.beginTransaction();
                transaction.replace(R.id.container, new NewCommentFragment());
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });

        buttonAddMoment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
                FragmentTransaction transaction = fragmentManager.beginTransaction();
                transaction.replace(R.id.container, new NewCommentFragment());
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });

        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Caution");
                builder.setMessage("Are you sure you want to delete the book");

                builder.setPositiveButton("Accept", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        PersonalBookDao personalBookDao = AppDatabase.getInstance(requireContext()).personalBookDao();

                        AsyncTask.execute(new Runnable() {
                            @Override
                            public void run() {
                                long bookIdToDelete = selectedBook.getId();
                                personalBookDao.deletePersonalBookById(bookIdToDelete);
                            }
                        });
                        FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
                        fragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                    }
                });

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });




        return view;
    }




}
