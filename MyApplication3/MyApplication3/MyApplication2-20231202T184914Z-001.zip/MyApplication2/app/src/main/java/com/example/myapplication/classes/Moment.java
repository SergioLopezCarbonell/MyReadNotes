package com.example.myapplication.classes;

public class Moment {

    private String Chapter;
    private String Page;
    private String Category;
    private String body;
}
