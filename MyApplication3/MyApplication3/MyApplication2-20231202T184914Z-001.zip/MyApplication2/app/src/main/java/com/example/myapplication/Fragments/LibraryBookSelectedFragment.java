package com.example.myapplication.Fragments;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ViewFlipper;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.myapplication.AppDatabase;
import com.example.myapplication.R;
import com.example.myapplication.classes.Book;
import com.example.myapplication.dao.PersonalBookDao;
import com.example.myapplication.entitys.PersonalBookEntity;

public class LibraryBookSelectedFragment extends Fragment {

    private Book selectedBook;

    public LibraryBookSelectedFragment(Book book) {
        this.selectedBook = book;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_library_selectedbook, container, false);


        String title = selectedBook.getTitle();
        String author = selectedBook.getAuthor();
        int coverResource = selectedBook.getCoverResource();

        ImageView imageView = view.findViewById(R.id.BookImage);
        imageView.setImageResource(coverResource);

        TextView textViewTitle = view.findViewById(R.id.TitleTextView);
        textViewTitle.setText(title);

        TextView textViewAuthor = view.findViewById(R.id.AuthorTextView);
        textViewAuthor.setText(author);

        Button buttonAdd = view.findViewById(R.id.buttonAdd);

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PersonalBookEntity personalBookEntity = new PersonalBookEntity(
                        selectedBook.getTitle(),
                        selectedBook.getAuthor(),
                        selectedBook.getCoverResource(),
                        selectedBook.getCategory());

                        PersonalBookDao personalBookDao = AppDatabase.getInstance(requireContext()).personalBookDao();
                        AsyncTask.execute(new Runnable() {
                            @Override
                            public void run() {
                                long insertedId = personalBookDao.insertPersonalBook(personalBookEntity);
                                Log.d("Se ha insertado? ", String.valueOf(insertedId));
                            }
                        });
            }
        });



        return view;
    }




}
