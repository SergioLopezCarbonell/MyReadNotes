package com.example.myapplication.classes;

public class Comment {

    private String title;
    private String category;
    private String body;
}
