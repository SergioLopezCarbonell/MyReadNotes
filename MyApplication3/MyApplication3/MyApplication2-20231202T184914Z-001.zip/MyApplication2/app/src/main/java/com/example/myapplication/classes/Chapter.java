package com.example.myapplication.classes;

public class Chapter {
    private String title;
}
