package com.example.myapplication.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.adapters.BookAdapter;
import com.example.myapplication.adapters.LibraryBookAdapter;
import com.example.myapplication.classes.Book;

import java.util.ArrayList;

public class LibraryFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_library, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.recycler_view);
        SearchView searchView = view.findViewById(R.id.searchView);

        ArrayList<Book> books = new ArrayList<>();

        Book bookExample = new Book("DON QUIJOTE"," Miguel de Cervantes Saavedra",R.drawable.donquijote, "Aventuras");
        Book bookExample1 = new Book("HOLLY", " Stephen King",R.drawable.holly, "Thriller");
        Book bookExample2 = new Book("MALDITA ROMA","Santiago Posteguillo",R.drawable.malditaroma,"Drama");
        Book bookExample3 = new Book("DON QUIJOTE"," Miguel de Cervantes Saavedra",R.drawable.donquijote,"Aventuras");

        books = new ArrayList<>();
        books.add(bookExample);
        books.add(bookExample1);
        books.add(bookExample2);
        books.add(bookExample2);
        books.add(bookExample2);
        books.add(bookExample3);
        books.add(bookExample1);

        LibraryBookAdapter LibraryBookAdapter = new LibraryBookAdapter(getContext(), books);


        int numberOfColumns = 1;
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), numberOfColumns));
        recyclerView.setAdapter(LibraryBookAdapter);

        LibraryBookAdapter.setOnItemClickListener(new LibraryBookAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Book book) {
                FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.container, new LibraryBookSelectedFragment(book));
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        return view;
    }
    

}
