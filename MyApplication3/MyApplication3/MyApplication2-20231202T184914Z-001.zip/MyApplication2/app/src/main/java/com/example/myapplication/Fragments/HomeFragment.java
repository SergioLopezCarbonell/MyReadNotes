package com.example.myapplication.Fragments;

import android.os.AsyncTask;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.myapplication.AppDatabase;
import com.example.myapplication.adapters.BookAdapter;
import com.example.myapplication.R;
import com.example.myapplication.classes.Book;
import com.example.myapplication.classes.PersonalBook;
import com.example.myapplication.dao.PersonalBookDao;
import com.example.myapplication.entitys.PersonalBookEntity;

import java.util.ArrayList;
import java.util.List;


public class HomeFragment extends Fragment {


    private RecyclerView recyclerView;
    private BookAdapter bookAdapter;
    private List<PersonalBookEntity> books;


    public HomeFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_book, container, false);

        recyclerView = view.findViewById(R.id.recycler_view);


        Book bookExample = new Book("DON QUIJOTE"," Miguel de Cervantes Saavedra",R.drawable.donquijote, "Aventuras");


        //TESTS----------------------------------------

        PersonalBook personalBook = new PersonalBook(
                bookExample.getTitle(),
                bookExample.getAuthor(),
                bookExample.getCoverResource(),
                bookExample.getCategory()
        );

        PersonalBookEntity personalBookEntity = new PersonalBookEntity(
                bookExample.getTitle(),
                bookExample.getAuthor(),
                bookExample.getCoverResource(),
                bookExample.getCategory()
        );

        PersonalBookDao personalBookDao = AppDatabase.getInstance(requireContext()).personalBookDao();
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {

                //long insertedId = personalBookDao.insertPersonalBook(personalBookEntity);
                //Log.d("Se ha insertado? ", String.valueOf(insertedId));
            }
        });

        books = new ArrayList<PersonalBookEntity>();

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                books = personalBookDao.getAllPersonalBooks();

                requireActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (recyclerView.getAdapter() == null) {

                            bookAdapter = new BookAdapter(getContext(), books);
                            recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 3));
                            recyclerView.setAdapter(bookAdapter);

                            bookAdapter.setOnItemClickListener(new BookAdapter.OnItemClickListener() {
                                @Override
                                public void onItemClick(PersonalBookEntity book) {
                                    FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
                                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                                    fragmentTransaction.replace(R.id.container, new BookSelectedFragment(book));
                                    fragmentTransaction.addToBackStack(null);
                                    fragmentTransaction.commit();
                                }
                            });
                        }
                        else{
                            bookAdapter.updateData(books);
                        }

                    }
                });
            }
        });

        return view;
    }
}