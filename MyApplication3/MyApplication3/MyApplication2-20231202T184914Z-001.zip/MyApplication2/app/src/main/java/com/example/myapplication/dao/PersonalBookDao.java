package com.example.myapplication.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.myapplication.classes.PersonalBook;
import com.example.myapplication.entitys.PersonalBookEntity;

import java.util.List;

@Dao
public interface PersonalBookDao {

    @Insert
    long insertPersonalBook(PersonalBookEntity personalBook);

    @Query("SELECT * FROM personal_books")
    List<PersonalBookEntity> getAllPersonalBooks();

    @Query("DELETE FROM personal_books")
    void deleteAllPersonalBooks();

    @Query("DELETE FROM personal_books WHERE id = :personalBookId")
    void deletePersonalBookById(long personalBookId);
}
